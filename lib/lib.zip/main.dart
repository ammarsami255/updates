import 'package:flutter/material.dart';
import 'package:el_moza3/Constants.dart';
import 'package:el_moza3/widget/login_screen.dart';
import 'package:el_moza3/screens/main_screen.dart';

void main() => runApp(const MyApp());

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  static bool isLoggedIn = false;

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Cairo',
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary),
        useMaterial3: true,
      ),
      initialRoute: MainScreen.id,
      routes: {
        MainScreen.id: (context) => MainScreen(
          onRequireLogin: () async {
            await Navigator.pushNamed(context, LoginScreen.id);
            setState(() {});
          },
        ),
        LoginScreen.id: (context) => LoginScreen(
          onLoginSuccess: () {
            MyApp.isLoggedIn = true;
            Navigator.pop(context);
          },
        ),
      },
    );
  }
}

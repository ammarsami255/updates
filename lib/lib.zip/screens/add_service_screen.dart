import 'package:flutter/material.dart';
import 'package:el_moza3/Constants.dart';

class AddServiceScreen extends StatefulWidget {
  const AddServiceScreen({super.key});

  @override
  State<AddServiceScreen> createState() => _AddServiceScreenState();
}

class _AddServiceScreenState extends State<AddServiceScreen> {
  final _titleController = TextEditingController();
  final _descController = TextEditingController();
  final _priceController = TextEditingController();
  final _phoneController = TextEditingController();

  String _selectedCategory = "خدمات مهنية";
  String _selectedType = "عرض خدمة";
  String _selectedLocation = "القاهرة";

  static const List<String> _categories = [
    "خدمات مهنية",
    "صناعة وتصنيع",
    "مقاولات",
    "نقل ولوجستيات",
  ];

  static const List<String> _locations = [
    "القاهرة",
    "الإسكندرية",
    "الجيزة",
    "القاهرة الجديدة",
    "العاشر من رمضان",
    "السادس من أكتوبر",
    "شبرا الخيمة",
  ];

  void _submit() {
    if (_titleController.text.isEmpty || _descController.text.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("من فضلك اكمل البيانات")));
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("تم نشر الإعلان بنجاح ✓"),
        backgroundColor: Colors.green,
      ),
    );
    _titleController.clear();
    _descController.clear();
    _priceController.clear();
    _phoneController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background2,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "إضافة إعلان",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                "انشر خدمتك أو اطلب ما تحتاجه",
                style: TextStyle(fontSize: 13, color: AppColors.textSecondary),
              ),
              const SizedBox(height: 20),
              _section("نوع الإعلان"),
              Row(
                children: ["عرض خدمة", "طلب خدمة"].map((type) {
                  final selected = _selectedType == type;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () => setState(() => _selectedType = type),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.only(left: 8),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: selected ? AppColors.primary : Colors.white,
                          borderRadius: BorderRadius.circular(
                            AppSizes.borderRadius,
                          ),
                          border: Border.all(
                            color: selected
                                ? AppColors.primary
                                : AppColors.border,
                          ),
                        ),
                        child: Text(
                          type,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: selected
                                ? Colors.white
                                : AppColors.textSecondary,
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 20),
              _section("التصنيف"),
              _dropdown(
                _categories,
                _selectedCategory,
                (v) => setState(() => _selectedCategory = v!),
              ),
              const SizedBox(height: 16),
              _section("عنوان الإعلان"),
              _field(_titleController, "مثال: مكتب محاسبة معتمد"),
              const SizedBox(height: 16),
              _section("وصف الخدمة"),
              _field(
                _descController,
                "اكتب تفاصيل الخدمة أو الطلب...",
                maxLines: 4,
              ),
              const SizedBox(height: 16),
              _section("السعر (اختياري)"),
              _field(_priceController, "مثال: 500 ج/ساعة أو تفاوض"),
              const SizedBox(height: 16),
              _section("الموقع"),
              _dropdown(
                _locations,
                _selectedLocation,
                (v) => setState(() => _selectedLocation = v!),
              ),
              const SizedBox(height: 16),
              _section("رقم التواصل"),
              _field(_phoneController, "01XXXXXXXXX"),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: AppSizes.buttonHeight,
                child: ElevatedButton(
                  onPressed: _submit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        AppSizes.borderRadius,
                      ),
                    ),
                  ),
                  child: const Text(
                    "نشر الإعلان",
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _section(String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
        ),
      ),
    );
  }

  Widget _field(TextEditingController ctrl, String hint, {int maxLines = 1}) {
    return TextField(
      controller: ctrl,
      textAlign: TextAlign.right,
      maxLines: maxLines,
      decoration: InputDecoration(
        hintText: hint,
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSizes.borderRadius),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSizes.borderRadius),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSizes.borderRadius),
          borderSide: const BorderSide(color: AppColors.primary),
        ),
      ),
    );
  }

  Widget _dropdown(
    List<String> items,
    String value,
    void Function(String?) onChanged,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppSizes.borderRadius),
        border: Border.all(color: AppColors.border),
      ),
      child: DropdownButton<String>(
        value: value,
        isExpanded: true,
        underline: const SizedBox(),
        items: items
            .map(
              (e) => DropdownMenuItem(
                value: e,
                child: Text(e, textAlign: TextAlign.right),
              ),
            )
            .toList(),
        onChanged: onChanged,
      ),
    );
  }
}

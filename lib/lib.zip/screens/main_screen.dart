import 'package:flutter/material.dart';
import 'package:el_moza3/Constants.dart';
import 'package:el_moza3/screens/services_screen.dart';
import 'package:el_moza3/screens/search_screen.dart';
import 'package:el_moza3/screens/add_service_screen.dart';
import 'package:el_moza3/screens/chat_screen.dart';
import 'package:el_moza3/screens/profile_screen.dart';

class MainScreen extends StatefulWidget {
  final Future<void> Function() onRequireLogin;

  const MainScreen({super.key, required this.onRequireLogin});

  static String id = "MainScreen";

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  void _onAddTap() async {
    if (!MyApp.isLoggedIn) {
      await widget.onRequireLogin();
      if (!MyApp.isLoggedIn) return;
    }
    setState(() => _currentIndex = 2);
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      ServicesScreen(onRequireLogin: widget.onRequireLogin),
      const SearchScreen(),
      MyApp.isLoggedIn ? const AddServiceScreen() : const SizedBox(),
      MyApp.isLoggedIn ? const ChatScreen() : const SizedBox(),
      ProfileScreen(onRequireLogin: widget.onRequireLogin),
    ];

    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: screens),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 12,
              offset: const Offset(0, -3),
            ),
          ],
        ),
        child: SafeArea(
          child: SizedBox(
            height: 60,
            child: Row(
              children: [
                _buildNavItem(0, Icons.home_rounded, "الرئيسية"),
                _buildNavItem(1, Icons.search_rounded, "بحث"),
                _buildAddButton(),
                _buildNavItem(3, Icons.chat_bubble_outline_rounded, "رسائل"),
                _buildNavItem(4, Icons.person_outline_rounded, "حسابي"),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(int index, IconData icon, String label) {
    final selected = _currentIndex == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _currentIndex = index),
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: selected ? AppColors.primary : AppColors.textSecondary,
              size: 24,
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                color: selected ? AppColors.primary : AppColors.textSecondary,
                fontWeight: selected ? FontWeight.w700 : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAddButton() {
    return Expanded(
      child: GestureDetector(
        onTap: _onAddTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Icon(
                Icons.add_rounded,
                color: Colors.white,
                size: 26,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MyApp {
  static bool isLoggedIn = false;
}

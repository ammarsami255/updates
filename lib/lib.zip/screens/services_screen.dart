import 'package:flutter/material.dart';
import 'package:el_moza3/Constants.dart';
import 'package:el_moza3/widget/service_card.dart';
import 'package:el_moza3/screens/service_detail_screen.dart';

class ServicesScreen extends StatefulWidget {
  final Future<void> Function() onRequireLogin;

  const ServicesScreen({super.key, required this.onRequireLogin});

  static String id = "ServicesScreen";

  // Publicly accessible list
  static final List<Map<String, dynamic>> listings = [
    {
      "title": "مكتب محاسبة قانوني معتمد",
      "category": "خدمات مهنية",
      "price": "500 ج/ساعة",
      "location": "القاهرة",
      "icon": Icons.account_balance,
      "color": Colors.blue,
      "type": "عرض خدمة",
      "description": "مكتب محاسبة معتمد بخبرة أكثر من 15 سنة...",
      "phone": "01012345678",
    },
    {
      "title": "مكتب استشارات هندسية",
      "category": "خدمات مهنية",
      "price": "800 ج/ساعة",
      "location": "الإسكندرية",
      "icon": Icons.engineering,
      "color": Colors.indigo,
      "type": "عرض خدمة",
      "description": "استشارات هندسية متخصصة في التصميم الإنشائي...",
      "phone": "01123456789",
    },
    {
      "title": "مطلب مستشار قانوني",
      "category": "خدمات مهنية",
      "price": "يُحدد لاحقاً",
      "location": "الجيزة",
      "icon": Icons.gavel,
      "color": Colors.deepPurple,
      "type": "طلب خدمة",
      "description": "مطلوب مستشار قانوني متخصص في قضايا العمل...",
      "phone": "01234567890",
    },
    {
      "title": "مصنع بلاستيك — طاقة فائضة",
      "category": "صناعة وتصنيع",
      "price": "تفاوض",
      "location": "العاشر من رمضان",
      "icon": Icons.precision_manufacturing,
      "color": Colors.orange,
      "type": "عرض خدمة",
      "description": "مصنع بلاستيك بطاقة إنتاجية فائضة جاهز...",
      "phone": "01098765432",
    },
    {
      "title": "ورشة حدادة وتشكيل معادن",
      "category": "صناعة وتصنيع",
      "price": "350 ج/ساعة",
      "location": "شبرا الخيمة",
      "icon": Icons.hardware,
      "color": Colors.brown,
      "type": "عرض خدمة",
      "description": "ورشة متخصصة في تشكيل المعادن والحدادة الفنية...",
      "phone": "01187654321",
    },
    {
      "title": "مطلوب مصنع تعبئة وتغليف",
      "category": "صناعة وتصنيع",
      "price": "يُحدد لاحقاً",
      "location": "السادس من أكتوبر",
      "icon": Icons.inventory_2,
      "color": Colors.amber,
      "type": "طلب خدمة",
      "description": "مطلوب مصنع تعبئة وتغليف لمنتجات غذائية...",
      "phone": "01276543210",
    },
    {
      "title": "مقاول تشطيبات سكنية",
      "category": "مقاولات",
      "price": "1200 ج/م²",
      "location": "القاهرة الجديدة",
      "icon": Icons.home_repair_service,
      "color": Colors.teal,
      "type": "عرض خدمة",
      "description": "متخصص في تشطيبات الوحدات السكنية والتجارية...",
      "phone": "01365432109",
    },
    {
      "title": "شركة مقاولات عمومية",
      "category": "مقاولات",
      "price": "تفاوض",
      "location": "القاهرة",
      "icon": Icons.construction,
      "color": Colors.green,
      "type": "عرض خدمة",
      "description": "شركة مقاولات عمومية معتمدة بخبرة 20 سنة...",
      "phone": "01454321098",
    },
    {
      "title": "مطلوب مقاول صرف صحي",
      "category": "مقاولات",
      "price": "يُحدد لاحقاً",
      "location": "الإسكندرية",
      "icon": Icons.plumbing,
      "color": Colors.cyan,
      "type": "طلب خدمة",
      "description": "مطلوب مقاول متخصص في أعمال الصرف الصحي...",
      "phone": "01543210987",
    },
    {
      "title": "شركة شحن داخلي — أسطول كامل",
      "category": "نقل ولوجستيات",
      "price": "تفاوض",
      "location": "القاهرة",
      "icon": Icons.local_shipping,
      "color": Colors.red,
      "type": "عرض خدمة",
      "description": "أسطول شحن داخلي متكامل يغطي جميع محافظات مصر...",
      "phone": "01632109876",
    },
    {
      "title": "مطلوب سائق توصيل يومي",
      "category": "نقل ولوجستيات",
      "price": "150 ج/يوم",
      "location": "الجيزة",
      "icon": Icons.drive_eta,
      "color": Colors.pink,
      "type": "طلب خدمة",
      "description": "مطلوب سائق للتوصيل اليومي داخل الجيزة...",
      "phone": "01721098765",
    },
  ];

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  int _selectedCategory = 0;

  static const List<Map<String, dynamic>> _categories = [
    {"label": "الكل", "icon": Icons.apps},
    {"label": "خدمات مهنية", "icon": Icons.business_center},
    {"label": "صناعة وتصنيع", "icon": Icons.factory},
    {"label": "مقاولات", "icon": Icons.construction},
    {"label": "نقل ولوجستيات", "icon": Icons.local_shipping},
  ];

  List<Map<String, dynamic>> get _filtered {
    if (_selectedCategory == 0) return ServicesScreen.listings;
    final cat = _categories[_selectedCategory]["label"] as String;
    return ServicesScreen.listings.where((e) => e["category"] == cat).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.background1, AppColors.background2],
          ),
        ),
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final w = constraints.maxWidth;
              final isMobile = w < AppSizes.mobileBreakpoint;
              final isDesktop = w >= AppSizes.tabletBreakpoint;
              final crossAxisCount = isMobile ? 1 : isDesktop ? 3 : 2;

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(),
                  const SizedBox(height: 10),
                  _buildCategories(),
                  _buildCount(),
                  Expanded(
                    child: GridView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                      itemCount: _filtered.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: crossAxisCount,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: isMobile ? 3.2 : 1.6,
                      ),
                      itemBuilder: (context, index) {
                        final item = _filtered[index];
                        return ServiceCard(
                          title: item["title"]!,
                          category: item["category"]!,
                          price: item["price"]!,
                          location: item["location"]!,
                          icon: item["icon"] as IconData,
                          color: item["color"] as Color,
                          type: item["type"]!,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ServiceDetailScreen(
                                  item: item,
                                  onRequireLogin: widget.onRequireLogin,
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.storefront, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 10),
          const Text(
            "الموزّع",
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: AppColors.textPrimary,
            ),
          ),
          const Spacer(),
          IconButton(
            icon: const Icon(
              Icons.notifications_none_rounded,
              color: AppColors.textPrimary,
            ),
            onPressed: () {},
          ),
        ],
      ),
    );
  }

  Widget _buildCategories() {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final selected = _selectedCategory == index;
          return GestureDetector(
            onTap: () => setState(() => _selectedCategory = index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: selected ? AppColors.primary : Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: selected ? AppColors.primary : AppColors.border,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    _categories[index]["icon"] as IconData,
                    size: 15,
                    color: selected ? Colors.white : AppColors.textSecondary,
                  ),
                  const SizedBox(width: 5),
                  Text(
                    _categories[index]["label"] as String,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: selected ? Colors.white : AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildCount() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Text(
        "${_filtered.length} إعلان",
        style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
      ),
    );
  }
}
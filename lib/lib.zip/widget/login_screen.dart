import 'package:flutter/material.dart';
import 'package:el_moza3/Constants.dart';

class LoginScreen extends StatefulWidget {
  final VoidCallback onLoginSuccess;

  const LoginScreen({super.key, required this.onLoginSuccess});

  static String id = "LoginScreen";

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _obscurePassword = true;
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  String? _error;

  void _handleLogin() {
    if (_emailController.text == "admin@moza3.com" &&
        _passwordController.text == "1234") {
      widget.onLoginSuccess();
    } else {
      setState(() {
        _error = "بيانات غلط، جرب: admin@moza3.com / 1234";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.background1, AppColors.background2],
          ),
        ),
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final w = constraints.maxWidth;
              final isMobile = w < AppSizes.mobileBreakpoint;
              final isDesktop = w >= AppSizes.tabletBreakpoint;
              final cardWidth = isDesktop ? 420.0 : double.infinity;

              return Center(
                child: SingleChildScrollView(
                  child: Container(
                    width: cardWidth,
                    padding: const EdgeInsets.all(AppSizes.defaultPadding),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const SizedBox(height: 40),
                        _buildHeader(isMobile),
                        const SizedBox(height: 40),
                        _buildForm(),
                        if (_error != null) ...[
                          const SizedBox(height: 8),
                          Text(
                            _error!,
                            style: const TextStyle(color: Colors.red, fontSize: 13),
                            textAlign: TextAlign.center,
                          ),
                        ],
                        const SizedBox(height: 20),
                        _buildButton(),
                        const SizedBox(height: 10),
                        _buildFooter(),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(bool isMobile) {
    return Column(
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(AppSizes.borderRadius),
          ),
          child: const Icon(Icons.storefront, color: Colors.white, size: 40),
        ),
        const SizedBox(height: 20),
        Text(
          "منصة الموزع",
          style: TextStyle(
            fontSize: isMobile ? AppSizes.titleSizeMobile : AppSizes.titleSizeTablet,
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          "سجّل دخولك للمتابعة",
          style: TextStyle(
            fontSize: isMobile ? AppSizes.subtitleSizeMobile : AppSizes.subtitleSizeTablet,
            color: AppColors.textSecondary,
          ),
        ),
      ],
    );
  }

  Widget _buildForm() {
    return Column(
      children: [
        _buildField(
          hint: "البريد الإلكتروني",
          icon: Icons.email_outlined,
          obscure: false,
          controller: _emailController,
        ),
        const SizedBox(height: 15),
        _buildField(
          hint: "كلمة المرور",
          icon: Icons.lock_outline,
          obscure: _obscurePassword,
          controller: _passwordController,
          suffix: IconButton(
            icon: Icon(_obscurePassword ? Icons.visibility : Icons.visibility_off),
            onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
          ),
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton(
            onPressed: () {},
            child: const Text("نسيت كلمة المرور؟",
                style: TextStyle(color: AppColors.primary)),
          ),
        ),
      ],
    );
  }

  Widget _buildField({
    required String hint,
    required IconData icon,
    required bool obscure,
    required TextEditingController controller,
    Widget? suffix,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      textAlign: TextAlign.right,
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: Icon(icon, color: AppColors.primary),
        suffixIcon: suffix,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSizes.borderRadius),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSizes.borderRadius),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppSizes.borderRadius),
          borderSide: const BorderSide(color: AppColors.primary),
        ),
      ),
    );
  }

  Widget _buildButton() {
    return SizedBox(
      width: double.infinity,
      height: AppSizes.buttonHeight,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppSizes.borderRadius),
          ),
        ),
        onPressed: _handleLogin,
        child: const Text(
          "تسجيل الدخول",
          style: TextStyle(fontSize: 16, color: Colors.white),
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        TextButton(
          onPressed: () {},
          child: const Text("إنشاء حساب",
              style: TextStyle(color: AppColors.primary)),
        ),
        const Text("ليس لديك حساب؟",
            style: TextStyle(color: AppColors.textSecondary)),
      ],
    );
  }
}